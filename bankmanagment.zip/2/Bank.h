#ifndef BANK_H
#define BANK_H

#include "Account.h"
#include <vector>
#include <string>

// Bank owns all accounts in memory during a session and is responsible
// for syncing them to/from disk (data/accounts.dat) so records persist
// between runs of the program.
class Bank {
private:
    std::vector<Account> accounts;
    std::string dataFile;
    std::string logFile;

    int generateAccountNumber() const;
    int findAccountIndex(int accNo) const;
    void logTransaction(const std::string& entry);

public:
    Bank(const std::string& dataFilePath = "data/accounts.dat",
         const std::string& logFilePath = "data/transactions.log");

    void loadFromFile();
    void saveToFile() const;

    // Core operations. Each returns true/false and prints its own
    // user-facing messages so main() can stay a thin menu loop.
    int createAccount(const std::string& name, const std::string& pin,
                       double initialDeposit, const std::string& type);
    bool deposit(int accNo, const std::string& pin, double amount);
    bool withdraw(int accNo, const std::string& pin, double amount);
    bool checkBalance(int accNo, const std::string& pin);
    bool closeAccount(int accNo, const std::string& pin);

    void listAllAccounts() const;
    bool accountExists(int accNo) const;
};

#endif

#ifndef ACCOUNT_H
#define ACCOUNT_H

#include <string>
#include <fstream>

// Represents a single bank account.
// Kept as a simple, fixed-size record so it can be written to / read
// from a binary file directly (fast, simple persistence layer).
class Account {
private:
    int accountNumber;
    char name[50];
    char pin[5];        // 4-digit PIN stored as a C-string (+ null terminator)
    double balance;
    char accountType[15]; // "Savings" or "Current"

public:
    Account(); // required so Account can be used with fstream::read/write
    Account(int accNo, const std::string& holderName, const std::string& pinCode,
            double initialDeposit, const std::string& type);

    // Getters
    int getAccountNumber() const;
    std::string getName() const;
    double getBalance() const;
    std::string getAccountType() const;

    // Security
    bool verifyPin(const std::string& enteredPin) const;

    // Transactions (return true on success)
    bool deposit(double amount);
    bool withdraw(double amount);

    // Display
    void display() const;
};

#endif

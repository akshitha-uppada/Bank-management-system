#include "Account.h"
#include <cstring>
#include <iostream>
#include <iomanip>

Account::Account() : accountNumber(0), balance(0.0) {
    name[0] = '\0';
    pin[0] = '\0';
    accountType[0] = '\0';
}

Account::Account(int accNo, const std::string& holderName, const std::string& pinCode,
                  double initialDeposit, const std::string& type)
    : accountNumber(accNo), balance(initialDeposit) {
    strncpy(name, holderName.c_str(), sizeof(name) - 1);
    name[sizeof(name) - 1] = '\0';

    strncpy(pin, pinCode.c_str(), sizeof(pin) - 1);
    pin[sizeof(pin) - 1] = '\0';

    strncpy(accountType, type.c_str(), sizeof(accountType) - 1);
    accountType[sizeof(accountType) - 1] = '\0';
}

int Account::getAccountNumber() const { return accountNumber; }
std::string Account::getName() const { return std::string(name); }
double Account::getBalance() const { return balance; }
std::string Account::getAccountType() const { return std::string(accountType); }

bool Account::verifyPin(const std::string& enteredPin) const {
    return enteredPin == std::string(pin);
}

bool Account::deposit(double amount) {
    if (amount <= 0) return false;
    balance += amount;
    return true;
}

bool Account::withdraw(double amount) {
    if (amount <= 0) return false;
    if (amount > balance) return false; // insufficient funds
    balance -= amount;
    return true;
}

void Account::display() const {
    std::cout << std::left
               << std::setw(12) << accountNumber
               << std::setw(20) << name
               << std::setw(12) << accountType
               << std::fixed << std::setprecision(2) << balance
               << std::endl;
}

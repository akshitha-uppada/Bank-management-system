#include "Bank.h"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <ctime>
#include <cstring>
#include <sys/stat.h>

Bank::Bank(const std::string& dataFilePath, const std::string& logFilePath)
    : dataFile(dataFilePath), logFile(logFilePath) {
    // Make sure the data/ directory exists before we try to read/write into it.
    mkdir("data", 0755);
    loadFromFile();
}

void Bank::loadFromFile() {
    accounts.clear();
    std::ifstream in(dataFile, std::ios::binary);
    if (!in) return; // no file yet on first run — that's fine

    Account acc;
    while (in.read(reinterpret_cast<char*>(&acc), sizeof(Account))) {
        accounts.push_back(acc);
    }
    in.close();
}

void Bank::saveToFile() const {
    std::ofstream out(dataFile, std::ios::binary | std::ios::trunc);
    if (!out) {
        std::cerr << "Error: could not write to data file.\n";
        return;
    }
    for (const auto& acc : accounts) {
        out.write(reinterpret_cast<const char*>(&acc), sizeof(Account));
    }
    out.close();
}

void Bank::logTransaction(const std::string& entry) {
    std::ofstream out(logFile, std::ios::app);
    if (!out) return;
    std::time_t t = std::time(nullptr);
    char buf[26];
    std::strncpy(buf, std::ctime(&t), sizeof(buf));
    buf[24] = '\0'; // strip trailing newline from ctime output
    out << "[" << buf << "] " << entry << "\n";
}

int Bank::generateAccountNumber() const {
    // Simple scheme: 1001, 1002, ... based on the highest existing number.
    int maxNo = 1000;
    for (const auto& acc : accounts) {
        if (acc.getAccountNumber() > maxNo) maxNo = acc.getAccountNumber();
    }
    return maxNo + 1;
}

int Bank::findAccountIndex(int accNo) const {
    for (size_t i = 0; i < accounts.size(); i++) {
        if (accounts[i].getAccountNumber() == accNo) return static_cast<int>(i);
    }
    return -1;
}

bool Bank::accountExists(int accNo) const {
    return findAccountIndex(accNo) != -1;
}

int Bank::createAccount(const std::string& name, const std::string& pin,
                         double initialDeposit, const std::string& type) {
    if (initialDeposit < 0) {
        std::cout << "Initial deposit cannot be negative.\n";
        return -1;
    }
    if (pin.length() != 4) {
        std::cout << "PIN must be exactly 4 digits.\n";
        return -1;
    }

    int newAccNo = generateAccountNumber();
    accounts.emplace_back(newAccNo, name, pin, initialDeposit, type);
    saveToFile();
    logTransaction("CREATE account #" + std::to_string(newAccNo) + " for " + name);

    std::cout << "\nAccount created successfully!\n";
    std::cout << "Your Account Number: " << newAccNo << "  (keep this safe)\n";
    return newAccNo;
}

bool Bank::deposit(int accNo, const std::string& pin, double amount) {
    int idx = findAccountIndex(accNo);
    if (idx == -1) {
        std::cout << "Account not found.\n";
        return false;
    }
    if (!accounts[idx].verifyPin(pin)) {
        std::cout << "Incorrect PIN.\n";
        return false;
    }
    if (!accounts[idx].deposit(amount)) {
        std::cout << "Deposit amount must be positive.\n";
        return false;
    }
    saveToFile();
    logTransaction("DEPOSIT " + std::to_string(amount) + " to #" + std::to_string(accNo));
    std::cout << "Deposit successful. New balance: " << std::fixed
               << std::setprecision(2) << accounts[idx].getBalance() << "\n";
    return true;
}

bool Bank::withdraw(int accNo, const std::string& pin, double amount) {
    int idx = findAccountIndex(accNo);
    if (idx == -1) {
        std::cout << "Account not found.\n";
        return false;
    }
    if (!accounts[idx].verifyPin(pin)) {
        std::cout << "Incorrect PIN.\n";
        return false;
    }
    if (!accounts[idx].withdraw(amount)) {
        std::cout << "Withdrawal failed: invalid amount or insufficient balance.\n";
        return false;
    }
    saveToFile();
    logTransaction("WITHDRAW " + std::to_string(amount) + " from #" + std::to_string(accNo));
    std::cout << "Withdrawal successful. New balance: " << std::fixed
               << std::setprecision(2) << accounts[idx].getBalance() << "\n";
    return true;
}

bool Bank::checkBalance(int accNo, const std::string& pin) {
    int idx = findAccountIndex(accNo);
    if (idx == -1) {
        std::cout << "Account not found.\n";
        return false;
    }
    if (!accounts[idx].verifyPin(pin)) {
        std::cout << "Incorrect PIN.\n";
        return false;
    }
    std::cout << "\nAccount Holder: " << accounts[idx].getName() << "\n";
    std::cout << "Account Type  : " << accounts[idx].getAccountType() << "\n";
    std::cout << "Balance       : " << std::fixed << std::setprecision(2)
               << accounts[idx].getBalance() << "\n";
    return true;
}

bool Bank::closeAccount(int accNo, const std::string& pin) {
    int idx = findAccountIndex(accNo);
    if (idx == -1) {
        std::cout << "Account not found.\n";
        return false;
    }
    if (!accounts[idx].verifyPin(pin)) {
        std::cout << "Incorrect PIN.\n";
        return false;
    }
    logTransaction("CLOSE account #" + std::to_string(accNo));
    accounts.erase(accounts.begin() + idx);
    saveToFile();
    std::cout << "Account closed successfully.\n";
    return true;
}

void Bank::listAllAccounts() const {
    if (accounts.empty()) {
        std::cout << "No accounts found.\n";
        return;
    }
    std::cout << "\n" << std::left
               << std::setw(12) << "AccNo"
               << std::setw(20) << "Name"
               << std::setw(12) << "Type"
               << "Balance\n";
    std::cout << std::string(56, '-') << "\n";
    for (const auto& acc : accounts) {
        acc.display();
    }
}

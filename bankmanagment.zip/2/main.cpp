#include "Bank.h"
#include <iostream>
#include <limits>

// Clears bad input state and discards the rest of the line.
// Used whenever cin >> fails (e.g. user types letters where a number is expected).
void clearInput() {
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

double readAmount(const std::string& prompt) {
    double amount;
    std::cout << prompt;
    while (!(std::cin >> amount)) {
        std::cout << "Invalid input. Enter a numeric amount: ";
        clearInput();
    }
    return amount;
}

int readAccountNumber() {
    int accNo;
    std::cout << "Enter Account Number: ";
    while (!(std::cin >> accNo)) {
        std::cout << "Invalid input. Enter a numeric account number: ";
        clearInput();
    }
    return accNo;
}

std::string readPin() {
    std::string pin;
    std::cout << "Enter 4-digit PIN: ";
    std::cin >> pin;
    return pin;
}

void printMenu() {
    std::cout << "\n===== BANK MANAGEMENT SYSTEM =====\n";
    std::cout << "1. Create New Account\n";
    std::cout << "2. Deposit\n";
    std::cout << "3. Withdraw\n";
    std::cout << "4. Check Balance\n";
    std::cout << "5. List All Accounts\n";
    std::cout << "6. Close Account\n";
    std::cout << "7. Exit\n";
    std::cout << "Choose an option: ";
}

int main() {
    Bank bank; // loads existing accounts from data/accounts.dat automatically

    std::cout << "Welcome to the C++ Bank Management Application\n";

    int choice;
    bool running = true;

    while (running) {
        printMenu();
        if (!(std::cin >> choice)) {
            std::cout << "Invalid option.\n";
            clearInput();
            continue;
        }

        switch (choice) {
            case 1: {
                clearInput();
                std::string name, type;
                std::cout << "Enter Full Name: ";
                std::getline(std::cin, name);

                std::string pin = readPin();

                std::cout << "Account Type (Savings/Current): ";
                std::cin >> type;

                double initial = readAmount("Initial Deposit Amount: ");

                bank.createAccount(name, pin, initial, type);
                break;
            }
            case 2: {
                int accNo = readAccountNumber();
                std::string pin = readPin();
                double amount = readAmount("Enter amount to deposit: ");
                bank.deposit(accNo, pin, amount);
                break;
            }
            case 3: {
                int accNo = readAccountNumber();
                std::string pin = readPin();
                double amount = readAmount("Enter amount to withdraw: ");
                bank.withdraw(accNo, pin, amount);
                break;
            }
            case 4: {
                int accNo = readAccountNumber();
                std::string pin = readPin();
                bank.checkBalance(accNo, pin);
                break;
            }
            case 5: {
                bank.listAllAccounts();
                break;
            }
            case 6: {
                int accNo = readAccountNumber();
                std::string pin = readPin();
                std::cout << "Are you sure you want to close this account? (y/n): ";
                char confirm;
                std::cin >> confirm;
                if (confirm == 'y' || confirm == 'Y') {
                    bank.closeAccount(accNo, pin);
                } else {
                    std::cout << "Cancelled.\n";
                }
                break;
            }
            case 7:
                std::cout << "Thank you for using the Bank Management Application. Goodbye!\n";
                running = false;
                break;
            default:
                std::cout << "Invalid option. Please choose between 1 and 7.\n";
        }
    }

    return 0;
}
